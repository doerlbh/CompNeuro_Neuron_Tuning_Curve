
% here we take 1000 trials as an example.

%ResponseMeanandStd = zeros (2, 400);

global stdall;

for k = 1:400
    meanall(k) = generateNoisyDataGeneral(k);
end

stmls = 1:400; 

figure;
plot(stmls,meanall(stmls))
title('Tuning Curve')
xlabel('Stimulus')
ylabel('Response')
errorbar(meanall(stmls), stdall(stmls))

% I don't know why it goes like this: horizontal errorbar?

