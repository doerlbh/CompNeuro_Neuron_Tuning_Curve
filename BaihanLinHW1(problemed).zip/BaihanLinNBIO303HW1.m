%%
%**************************************************
% Question 1:

% make spiketrain workspace
generateNoisyData5090; % spiketrain5030 workspace: 50input, 90trials
generateNoisyData7090; % spiketrain7030 workspace: 70input, 90trials

% make rastor plot with two subplots.
figure;
subplot(2,1,1)
rastor5090 = imagesc(spiketrain5090);
xlabel('spikes')
ylabel('trails')
title('stimulus input = 50');
subplot(2,1,2)
rastor7090 = imagesc(spiketrain7090);
xlabel('spikes')
ylabel('trails');
title('stimulus input = 70');
%%
% make matrix to store the sum of spikes in each trail in a column
Sum5090 = sum(spiketrain5090, 2);
Sum7090 = sum(spiketrain7090, 2);

% calculate the means of spikes in different trails
Mean5090 = mean(Sum5090);
Mean7090 = mean(Sum7090);

% calculate the standard deviation of spikes in different trails
Std5090 = std(Sum5090);
Std7090 = std(Sum7090);
%%
% ***********************************************************
% Question 2:
 
f5090(x) = exp(-(x-mean5090)^2/(2*std5090.^2))/(std5090*sqrt(2*pi)); % for normal distribution
f7090(x) = exp(-(x-mean7090)^2/(2*std7090.^2))/(std7090*sqrt(2*pi)); % for normal distribution

% make distribution histograph
figure; 
scale = 0:50;
Distribution5090 = histc(Sum5090, scale);
bar(scale,Distribution5090)
xlabel('spikes')
ylabel('frequency')
hold on
Distribution7090 = histc(Sum7090, scale);
bar(scale, Distribution7090,'r')
xlabel('spikes')
ylabel('frequency')
xlim([0 50])
ylim([0 20])
hold on % for normal distribution
plot(scale, f5090(x)) % for normal distribution
hold on % for normal distribution
plot(scale, f7090(x)) % for normal distribution

%%
% explor how discriminable

dprime = abs((Mean5090 - Mean7090)/sqrt((Std5090^2+Std7090^2)/2));

%%
% *******************************************************************
% Question 3
% Map out the tuning curve, with error bars

choice = input('Which of my 3 methods do you like to use? A, B, or C.')

switch choice
    case 'A'
        figureTuningCurveMethod1;
    case 'B'
        figureTuningCurveMethod2;
    case 'C'
        figureTuningCurveMethod3;
    otherwise
        disp('please make the right choice, alright?');
end


%%
% *******************************************************************
% Question 4

% I think of 3 methods. But I cannot test them because my model for
% question 3 is not ready.

% Method 1: Change tuning curve
% change tunningcurve function: f = 1./(1 + exp(-(x-50)/10)) 
% to 
% f = n*1./(1% + exp(-(m*x-50)/10)), where n and m both >1.

% Method 2: Change maxrate
% increase maxrate to increase rate and make bigger sample, thus more discriminable.

% Method 3: Change tau
% increase tau to increase ratecurve and make bigger sample, thus more discriminable.




