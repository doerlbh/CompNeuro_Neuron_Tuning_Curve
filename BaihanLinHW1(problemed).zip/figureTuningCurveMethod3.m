
% 3D matrix

alldata = zeros(ntrials, nmsec, 400);

ntrials = 1000;
nmsec = 300;   % number of milliseconds to record for
    times= 1:nmsec; % time units
    tau = 100;      % adaptation time constant in msec
%nbin = 400;

for k = 1:400
    x1 = k;
    
    maxrate = 300; % 30 Hz max firing rate

    rate = maxrate*tuningCurve(x1);         
    ratecurve = rate*exp(-times/tau)*.001;  % adapting rate function 

    for j = 1:ntrials;
        for i = 1:nmsec;
           if(rand(1)<ratecurve(i)),  
              alldata(j,i,k) = 1;
           end   
        end
    end;
end

allmean = mean(sum(alldata,3));
allstd = std(sum(alldata,3));

stmls = 1:400;

figure;
plot(stmls,allmean(stmls))
title('Tuning Curve')
xlabel('Stimulus')
ylabel('Response')
errorbar(allmean(stmls), allstd(stmls))

